# andrew-service
Reservation module in https://www.opentable.com/sons-and-daughters?p=2&sd=2018-06-09+21%3A00&page=1.
Injector.js loads data into the database for testing.

HOW TO START:
Start mysql server: type mysql.server start
Run mysql -u root < schema.sql
Now type npm run react-dev
Followed by npm start
Simply now type localhost:3000 in the chrome browser.

